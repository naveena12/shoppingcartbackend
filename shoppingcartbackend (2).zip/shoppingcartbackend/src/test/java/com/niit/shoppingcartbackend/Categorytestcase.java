package com.niit.shoppingcartbackend;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

//import com.niit.shoppingcart.model.Category;
//import com.niit.shoppingcartDAO.CategoryDAO;

public class Categorytestcase {
//	@Autowired
//	AnnotationConfigApplicationContext context;
//	@Autowired
//	Category category;
//	@Autowired
//	CategoryDAO categoryDAO;
//	public void init()
//	{
//		context = new AnnotationConfigApplicationContext();
//		context.scan("com.niit");
//		context.refresh();
//		CategoryDAO categoryDAO = (CategoryDAO) context.getBean("categoryDAO");
//		Category category = (Category) context.getBean("category");
//	}
//	//start writing junit test cases
//	//for each method defined in DAO
//	@Test
//	public void createCategoryTestCase()
//	{
//		category.setId("mob4");
//		category.setDescription("this is the electronic device");
//		category.setName("mobile Category");
//		boolean status= categoryDAO.save(category);
//
//	Assert.assertEquals("Create Category Test Case",true,status);
//		
//	}
}
   
	